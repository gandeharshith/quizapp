// Import the functions you need from the SDKs you need
import { initializeApp } from "firebase/app";
import { getAnalytics } from "firebase/analytics";
// src/firebaseConfig.js

import { getAuth } from 'firebase/auth';
import { getFirestore } from 'firebase/firestore';

const firebaseConfig = {
  apiKey: "AIzaSyCTrGB1j2IVw8-rG8ikaZHrKDgotaiVllE",
  authDomain: "quizapp-bd383.firebaseapp.com",
  projectId: "quizapp-bd383",
  storageBucket: "quizapp-bd383.appspot.com",
  messagingSenderId: "74952131060",
  appId: "1:74952131060:web:9242b5baa70fe91137f9a1",
  measurementId: "G-N8N3E96HER"
};


const app = initializeApp(firebaseConfig);
const auth = getAuth(app);
const db = getFirestore(app);

export { auth, db };